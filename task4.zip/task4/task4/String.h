#pragma once

using namespace std;

class String
{
private:
	string _string;
public:
	void SetString();
	string GetString();
	string CheckString(string _string);
	void MaxValue();
};
