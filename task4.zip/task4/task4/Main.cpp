#include <iostream>
#include "String.h"

using namespace std;

void main()
{

	setlocale(LC_ALL, "rus");
	String str;
	str.SetString();
	str.MaxValue();
}